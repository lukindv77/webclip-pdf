# Manual GitHub upload checkpoint

The associated starter archive contains `Upload-To-GitHub.ps1` and `repository_root/`.
Use that PowerShell flow to populate `lukindv77/webclip-pdf:main` from the exact WIP embedded in this handoff.

Expected pre-upload GitHub HEAD:
`e4ae66c6b677c6e49841caf3c9aa5ce7e970fa7a`

Do not use or recreate the old `.bootstrap` transport.
