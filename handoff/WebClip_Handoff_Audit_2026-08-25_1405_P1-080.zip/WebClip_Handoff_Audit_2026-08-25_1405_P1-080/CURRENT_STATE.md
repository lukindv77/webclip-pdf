# CURRENT STATE — WebClip audit handoff

Дата фиксации: **2026-08-25 12:30 +07:00**.

## Release state

- Extension: **WebClip PDF Prototype**.
- Manifest V3, minimum Chrome 118.
- Manifest version: **0.9.8** намеренно.
- Target after audit + real Chrome/Yandex E2E: `0.9.9`.
- Audit gate: **OPEN**.
- Release QA: **не завершён**.
- Private remote: GitHub `lukindv77/webclip-pdf`, `main`; перед использованием как canonical remote сначала подтвердить ручную PowerShell-загрузку starter package.

## Текущий physical WIP

`current_recovery_snapshot/current_wip/` содержит текущую cumulative ветку после закрытий feature-batch и последних history-reserved задач.

Последние физические closures, которые не переоткрывать без нового repro/regression evidence:

- P1-001 — SelectionSnapshot v3 scored restore/confidence/ambiguity;
- P1-003 — bounded resource prefetch/report перед PDF;
- P1-004 — cross-origin iframe через explicit optional host permission + frame-agent;
- P1-007 — browser integration selection/PDF/Journal/Yandex mocks;
- P1-008 — safe settings export/import без OAuth token;
- P1-009 — multiline Journal filter до pagination;
- P1-025 — Yandex file открывается через badge;
- P1-026 — единые счётчики и `Включены/Исключены`;
- P1-027 — destination/read badges без `Режим выгрузки`;
- P1-028 — badges в metadata row под title;
- P1-074 — bounded Journal import staging IDB;
- P1-079 — Full Journal native Save As page-owned;
- P1-080 — OperationLog native Save As page-owned;
- P1-090 — Yandex account/root/resource identity contract;
- P1-146 — automatic Blob download actual-settlement reconciliation.

Также сохраняются ранее закрытые audit rows P1-073, P1-075…P1-077, P1-082/P1-083, P1-086/P1-087, P1-094, P1-117…P1-123, P1-127, P1-145 и соответствующие P0/P2 regressions из canonical priorities.

## Что осталось физически закрыть из history-reserved P1

Новые номера не назначать:

- P1-081 — OperationLog v2 normal append/mutate/list/get/clear IDB transactions bounded/abortable;
- P1-084 — PDF retry-cache CRUD IDB transactions bounded/abortable;
- P1-085 — `journal.html` direct readonly IndexedDB timeout/abort + service-worker fallback;
- P1-124 — `tabs.create()` bounded + duplicate-safe late-result reconciliation;
- P1-125 — `scripting.executeScript()` bounded; late injection singleton-safe;
- P1-126 — оставшиеся service-worker `tabs.get()` bounded;
- P1-128 — hanging offscreen idle-close runtime message deadline + re-arm;
- P1-129 — prepared Save-As session checkpoint mutations serialized with late-settlement barrier;
- P1-130 — Chrome Action setIcon/setBadge/setTitle deadline + fence + global pending cap;
- P1-131 — unknown debugger attach/detach consumes global PDF pending budget.

## Registry reconciliation pending

- P1-138…P1-141: canonical runtime rows существуют, но поздняя разговорная ветка использовала те же номера для других physical alias-features. Не перенумеровывать без явной reconciliation.
- P1-142…P1-144: physical features/tests присутствуют, canonical reconciliation pending.
- Следующий безопасный новый P1 после проверки registry: **P1-147**.

## Security/data-integrity invariants

Сохранить session-only Yandex OAuth token, отсутствие refresh token, PKCE S256, fail-closed redirects, runtime trust boundaries, incognito boundary, canonical Yandex paths, bounded external/internal deadlines, non-cancellable Chrome API reconciliation, durable local/remote save checkpoints, atomic backup lease/recovery, bounded PDF retry cache, quota preflight, offscreen budgets/lifecycle, full PSL, bounded import metadata, OperationLog v2 redaction/retention.
