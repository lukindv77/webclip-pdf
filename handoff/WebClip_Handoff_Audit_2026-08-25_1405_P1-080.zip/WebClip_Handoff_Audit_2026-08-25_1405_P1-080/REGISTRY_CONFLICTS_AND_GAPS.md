# Registry conflicts and recovery gaps — 2026-08-25 12:30 +07:00

## Number reservation

Не переиспользовать P0-058…P0-062, P1-072…P1-146, P2-009…P2-013. Следующие новые номера только после canonical registry check: **P0-063 / P1-147 / P2-014**.

Current physical WIP дополнительно canonicalized as REGRESSION: P1-004, P1-008, P1-009, P1-025, P1-026, P1-027, P1-028, P1-074, P1-079, P1-080, P1-090. Ранее P1-001/P1-003/P1-007/P1-146 также физически закрыты.

## Conflict P1-138…P1-141

Canonical physical runtime rows:

- P1-138 — bounded read-only extension-page RPC deadlines;
- P1-139 — single-flight Yandex backup month listing;
- P1-140 — bounded Yandex picker DOM batches;
- P1-141 — dedupe/global budget unresolved timed-out read RPC.

Поздняя разговорная ветка использовала те же номера как aliases для journal notification/load-generation/backup telemetry features. Не перенумеровывать автоматически. При reconciliation alias-features потребуют свободные новые номера от P1-147, если canonical registry не докажет другое.

## P1-142…P1-145

- P1-142 — physical bounded/type-safe external Yandex scalar metadata; reconciliation pending.
- P1-143 — physical Options Yandex/backup status generation fencing; reconciliation pending.
- P1-144 — physical destructive Journal operation gate; reconciliation pending.
- P1-145 — canonical REGRESSION: OperationLog detail latest-wins queue/actual-settlement barrier.

## Historical continuity

Current WIP является source of truth для продолжения, но не объявляется доказательством непрерывной historical branch через original recovery gaps. Не делать вывод о наличии старого кода только по conversation history.
