# PENDING WORK

## P0

Формально известных OPEN P0 нет. Исторические P0-058…P0-062 зарезервированы и не переиспользуются. Следующий новый P0 после registry check: P0-063.

## P1 — ближайший history-reserved physical closure backlog

1. **P1-081** — OperationLog v2 normal append/mutate/list/get/clear IDB transactions bounded/abortable.
2. **P1-084** — PDF retry-cache CRUD IDB transactions bounded/abortable.
3. **P1-085** — `journal.html` direct readonly IDB timeout/abort + service-worker fallback.
4. **P1-124** — `tabs.create()` bounded + duplicate-safe late settlement reconciliation.
5. **P1-125** — `scripting.executeScript()` bounded; late injection singleton-safe.
6. **P1-126** — remaining service-worker `tabs.get()` bounded.
7. **P1-128** — offscreen idle-close runtime message deadline + cleanup re-arm.
8. **P1-129** — prepared Save-As checkpoint mutation serialization/late-settlement barrier.
9. **P1-130** — Chrome Action API deadlines/fence/global pending cap.
10. **P1-131** — debugger attach/detach unknown settlement participates in global PDF pending budget.

Эти коды уже history-reserved: не выдавать им новые номера и не считать старое описание доказательством physical implementation до проверки current code/tests.

## P1 registry reconciliation

- P1-138…P1-141 conflict: canonical runtime rows vs late alias-features.
- P1-142…P1-144 physical features/tests есть, canonical reconciliation pending.
- Следующий действительно новый P1: **P1-147**, только после registry check.

## P2 OPEN

P2-001…P2-008 остаются product backlog: HTML/Markdown export, local user folder, tracker integrations, tags/categories/metadata, full-text search, Shadow DOM selection scope, multiple snapshot formats, health telemetry. P2-009…P2-013 заняты history/regression; следующий новый P2: P2-014.

## Audit continuation

Продолжать deep audit: retained-memory peaks, external/internal deadlines, non-cancellable Chrome API late settlement, crash/hang/data-corruption multi-step flows, listener/port/timer/Blob/object URL/offscreen lifecycle, OAuth/Yandex/Chrome security, suppressed errors, architecture/efficiency, повторный audit каждого изменённого участка.
