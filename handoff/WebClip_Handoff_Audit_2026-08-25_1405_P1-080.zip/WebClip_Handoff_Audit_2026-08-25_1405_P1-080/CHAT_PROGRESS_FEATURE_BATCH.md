# CHAT PROGRESS FEATURE BATCH — superseded by physical closures

Исходный batch: `P1-001 / P1-003 / P1-004 / P1-007 / P1-008 / P1-009 / P1-025 / P1-026 / P1-027 / P1-028 / P1-090`.

На момент этого handoff **все перечисленные задачи имеют physical implementation, closure report и regression evidence в current WIP**. Старые разговорные intended designs и partial HTML больше не являются источником реализации и не должны накладываться поверх current code.

Использовать closure reports:

- `P1-001_CLOSURE.md`
- `P1-003_CLOSURE.md`
- `P1-004_CLOSURE.md`
- `P1-007_CLOSURE.md`
- `P1-008_CLOSURE.md`
- `P1-009_CLOSURE.md`
- `P1-025_CLOSURE.md`
- `P1-026_CLOSURE.md`
- `P1-027_CLOSURE.md`
- `P1-028_CLOSURE.md`
- `P1-090_CLOSURE.md`
