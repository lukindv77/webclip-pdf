# README FIRST — WebClip handoff 2026-08-25 12:30 +07:00

Это актуальный handoff для продолжения разработки Chrome Manifest V3 расширения **WebClip PDF Prototype** после физического закрытия P1-079/P1-080 и очистки неудачной bootstrap-синхронизации GitHub. До подтверждения ручной PowerShell-загрузки source of truth — вложенный current WIP.

## Критические правила

1. Главная кодовая база внутри архива: **`current_recovery_snapshot/current_wip/`**.
2. Canonical private remote: **`lukindv77/webclip-pdf`**, branch `main`.
3. Manifest намеренно остаётся **`0.9.8` / Manifest V3**. Не повышать до `0.9.9` до закрытия audit gate и реального Chrome/Yandex release QA.
4. Не переписывать реализацию с нуля, не откатывать current WIP на более старый recovery snapshot.
5. Не переиспользовать P-коды. История/late delta резервирует минимум до **P0-062 / P1-146 / P2-013**; следующий новый номер после registry-check: **P0-063 / P1-147 / P2-014**.
6. `P1-138…P1-141` имеют конфликт двух поздних веток; `P1-142…P1-144` physical features/tests есть, canonical reconciliation pending. Не исправлять номера молча.
7. Разговорный feature-progress не является доказательством кода. Закрытие = physical implementation/evidence + regression gate.
8. Handoff ZIP создавать только по прямому запросу пользователя. Git commit сам по себе не является release и не повышает manifest version.
9. Не обходить enterprise browser policy. Full unpacked Chrome + real Yandex остаётся release QA.
10. Shared Journal+Yandex destructive flow не менять без нового repro/OperationLog.

## Читать в новом чате строго в таком порядке

1. `README_FIRST.md`
2. `CURRENT_STATE.md`
3. `AUDIT_STATUS.md`
4. `PENDING_WORK.md`
5. `STATIC_CHECKS.md`
6. `REGISTRY_CONFLICTS_AND_GAPS.md`
7. `AUDIT_HISTORY_RESERVED_CODES.md`
8. `MERGE_AND_RECOVERY_ORDER.md`
9. `CHAT_PROGRESS_FEATURE_BATCH.md`
10. `GITHUB_SYNC.md`
11. `current_recovery_snapshot/current_wip/PROJECT_RECOVERY.md`
12. `current_recovery_snapshot/current_wip/project_docs/USER_REQUIREMENTS.md`
13. `current_recovery_snapshot/current_wip/project_docs/ARCHITECTURE.md`
14. `current_recovery_snapshot/current_wip/project_docs/DATA_MODELS.md`
15. `current_recovery_snapshot/current_wip/project_docs/TEST_PLAN.md`
16. `current_recovery_snapshot/current_wip/project_docs/PRIORITIES_P0_P1_P2.md`
17. `PROMPT_FOR_NEW_CHAT.md`

## Последний gate этой ревизии

- JavaScript `node --check`: **68/68 PASS**.
- deterministic `project_tools/test_*.js`: **55/55 PASS**.
- Chromium `144.0.7559.96`: P1-001 / P1-003 / P1-004 / P1-008 / P1-009 / P1-025 / P1-026 / P1-027 / P1-028 / P1-079/P1-080 browser regressions PASS.
- managed P1-007 integration PASS: selection/PDF/Journal/Yandex mocks; selected-only PDF **37,501 bytes**.
- P1-004 runner был синхронизирован с canonical P1-026 UI (`Включены`) после обнаружения устаревшего ожидания `Сохранить`; production runtime для этого не менялся.
- manifest JSON/MV3 PASS; version **0.9.8**.

Это **не release QA**.

## Generated nested recovery archive

Чтобы handoff не дублировал весь source второй раз, `current_wip/project_recovery/WebClip_Project_Recovery_v0_9_8.zip` намеренно не вложен в этот handoff. Он является generated artifact и воспроизводится из included source командой `python3 project_tools/build_recovery_archive.py`; непосредственно перед handoff локально был пересобран и `unzip -t` PASS.
