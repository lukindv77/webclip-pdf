# MERGE AND RECOVERY ORDER

1. Для продолжения сначала использовать `current_recovery_snapshot/current_wip/`. GitHub `lukindv77/webclip-pdf:main` считать той же ревизией только после проверки завершённой ручной PowerShell-загрузки.
2. Не накладывать старые P1-007/P1-146/P1-001/P1-003 closure deltas поверх current WIP: они уже включены.
3. Старый `unmerged_feature_batch_partial` больше не является рабочим источником: feature-batch P1-001/003/004/007/008/009/025/026/027/028/090 физически восстановлен и закрыт в current WIP.
4. History-reserved descriptions использовать как specification, а не как proof. Перед каждой из P1-081/084/085/124/125/126/128/129/130/131 физически сверять code/tests.
5. Перед новым P-code сверять `REGISTRY_CONFLICTS_AND_GAPS.md`.
6. После изменений: syntax + deterministic + релевантные Chromium regressions; manifest не повышать без release QA.
7. Handoff ZIP собирать только по прямому запросу пользователя.
