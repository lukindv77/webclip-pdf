# STATIC / BROWSER CHECKS — 2026-08-25 12:30 +07:00

Physical source: `current_recovery_snapshot/current_wip/`.

## Static/deterministic

- JavaScript `node --check`: **68/68 PASS**.
- deterministic `project_tools/test_*.js`: **55/55 PASS**.
- manifest JSON: PASS.
- `manifest_version = 3`: PASS.
- version = `0.9.8`: PASS.

## Chromium regression

Browser: Chromium `144.0.7559.96`.

- P1-001 selection restore: PASS — high/medium confidence, ambiguity fail-closed, legacy, iframe framePath.
- P1-003 resource prefetch: PASS — 5 attempted / 2 loaded / 3 failed, redaction/rollback PASS.
- P1-004 cross-origin frame-agent: PASS — SOP blocked direct DOM, remote include/restore, prepare/restore print, iframe expanded to 944 px.
- P1-008 settings export/import UI: PASS.
- P1-009 Journal multiline filter: PASS — 25 initial, 2 matches including record beyond first page, AND/OR/all fields.
- P1-025 Yandex badge: PASS.
- P1-026 Russian selection terminology/counter dedupe: PASS.
- P1-027 destination badges: PASS.
- P1-028 badge placement/sizes/narrow layout: PASS.
- P1-079/P1-080 page-owned Save As: PASS — one pending call, no caller timeout/retry/release while pending, terminal cleanup.
- P1-007 managed integration: PASS — selection, selected-only PDF **37,501 bytes**, Journal render, Yandex worker mocks/session-token assertion.

## Harness maintenance discovered during this gate

`browser_p1_004_cross_origin_iframe.py` still expected pre-P1-026 toolbar text `Сохранить: 1`; canonical UI now uses `Включены: 1 · Исключены: 0`. Harness expectation updated to `Включены: 1`, then P1-004 PASS. Production runtime unchanged by this maintenance.

## Not verified here

- full unpacked MV3 load in real Chrome/CfT;
- real optional host permission prompt against network cross-origin frame;
- real Yandex account/network;
- real user native Save As dialogs.
