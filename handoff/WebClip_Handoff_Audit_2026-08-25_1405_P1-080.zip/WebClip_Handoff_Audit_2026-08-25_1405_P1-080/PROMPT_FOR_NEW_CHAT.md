# Prompt для начала работы в новом чате

Я продолжаю разработку Chrome Manifest V3 расширения **WebClip PDF Prototype**. Приложен актуальный handoff после P1-079/P1-080 и очистки неудачной bootstrap-синхронизации GitHub.

Сначала распакуй архив и прочитай строго: `README_FIRST.md`, `CURRENT_STATE.md`, `AUDIT_STATUS.md`, `PENDING_WORK.md`, `STATIC_CHECKS.md`, `REGISTRY_CONFLICTS_AND_GAPS.md`, `AUDIT_HISTORY_RESERVED_CODES.md`, `MERGE_AND_RECOVERY_ORDER.md`, `CHAT_PROGRESS_FEATURE_BATCH.md`, `GITHUB_SYNC.md`, затем project docs внутри `current_recovery_snapshot/current_wip/`.

Критично:

- безусловный source of truth в этом архиве: `current_recovery_snapshot/current_wip/`;
- private GitHub: `lukindv77/webclip-pdf:main`; перед использованием как source of truth **сначала проверь**, что пользователь завершил ручную PowerShell-загрузку стартового пакета и в корне есть актуальный `manifest.json` MV3 / `0.9.8`;
- перед сборкой этого handoff активный `main` был очищен от незавершённых `.bootstrap`/temporary workflow и возвращён к clean commit `e4ae66c6b677c6e49841caf3c9aa5ce7e970fa7a`;
- не восстанавливай старый bootstrap transport: это была неудачная техника передачи файлов, не часть архитектуры продукта;
- manifest остаётся **0.9.8 / MV3** до полного release QA;
- не переиспользуй P-коды; следующий новый P1 только **P1-147** после registry check;
- P1-138…141 conflict и P1-142…144 reconciliation не исправляй молча;
- ближайший physical history-reserved backlog: **P1-081, P1-084, P1-085, P1-124, P1-125, P1-126, P1-128, P1-129, P1-130, P1-131**;
- shared Journal+Yandex destructive flow не менять без нового repro/OperationLog;
- enterprise browser policy не обходить;
- handoff архивы создавать только по моему запросу;
- перед каждой новой задачей сообщай справку: в чём проблема, как она проявляется для пользователя и как закрытие/незакрытие влияет на использование продукта.

Последний подтверждённый gate текущего WIP: **68/68 JS syntax, 55/55 deterministic**, Chromium regressions P1-001/003/004/008/009/025/026/027/028/079-080 PASS; managed P1-007 PASS, selected-only PDF около 37.5 KB; manifest 0.9.8/MV3.
