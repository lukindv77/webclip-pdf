# AUDIT HISTORY RESERVED CODES — current addendum

Этот файл сохраняет historical specifications. Старый исторический статус сам по себе **не является доказательством наличия current physical code**.

После текущего physical audit дополнительно доказаны/закрыты: **P1-074, P1-079, P1-080, P1-090**. Остались physical closure tasks: **P1-081, P1-084, P1-085, P1-124, P1-125, P1-126, P1-128, P1-129, P1-130, P1-131**.

Ниже сохранён исходный history-reserved specification из предыдущего handoff.

---
# Reserved audit history ledger — handoff 2026-08-25 08:30 +07:00

> Historical ledger retained verbatim from the previous emergency handoff. It is a requirements/reservation ledger, not automatic evidence that every row is physically present in current code.


**Важно:** ниже сохранён подробный historical ledger из предыдущего handoff. Использовать его как спецификацию требований, а не как автоматическое доказательство наличия кода. В текущем cumulative WIP часть этих строк уже физически восстановлена и закрыта отдельными closure files; при конфликте ориентироваться на `CURRENT_STATE.md`, `closures/`, текущий canonical `PRIORITIES_P0_P1_P2.md` и фактический код/tests.

---

# Reserved audit history not continuously present in mounted code

Этот файл сохраняет результаты аудита, которые были зафиксированы в истории текущей разработки, но полный непрерывный кодовый snapshot этого диапазона отсутствует в текущем контейнере. **Коды заняты и не переиспользуются.**

## P0-058…P0-062

- **P0-058 REGRESSION (history)** — Yandex remote save/backup verify должен fail-closed сверять точный ожидаемый remote byte size до journal/cache finalization; expected size обязателен, zero/unknown не считается успешной identity verification.
- **P0-059 REGRESSION (history)** — OAuth credential `storage.session/local` mutations после локального timeout являются non-cancellable side effects; введена serialization/late-settlement barrier, чтобы поздний старый token/remove не пересёк новую auth/logout mutation.
- **P0-060 REGRESSION (history)** — Incognito journal boundary fail-closed при неизвестном source/anchor tab; context-menu export shortcuts не обходят boundary.
- **P0-061 REGRESSION (history)** — после committed Yandex save вторичный badge/action refresh не может превратить успешную операцию в `ok:false`.
- **P0-062 REGRESSION (history)** — backup remote verify + durable success — commit point; scheduler/checkpoint housekeeping failure не переписывает success в failure; stale retry alarm после более нового success пропускается.

## P1-072…P1-088

- **P1-072 REGRESSION** — journal export batch ограничен memory budget (~4 Mi chars serialized), а не 250 потенциально огромных full records.
- **P1-073 REGRESSION** — общий export deadline охватывает revision read, temp chunk write и staging cleanup/open.
- **P1-074 REGRESSION** — import staging file-page write/read/delete IDB transactions bounded/abortable.
- **P1-075 REGRESSION** — maintenance cleanup IDB transactions имеют deadline, чтобы hung stage не блокировал recovery stages.
- **P1-076 REGRESSION** — backup lease acquire/renew/release transactions bounded; atomicity + token ownership сохранены.
- **P1-077 REGRESSION** — включение background backup через settings не запускает heavy backup fire-and-forget из `runtime.onMessage`; только планирует alarm.
- **P1-078 REGRESSION** — `storage.local/session.setAccessLevel(TRUSTED_CONTEXTS)` awaited/fail-closed до content-message handling/injection.
- **P1-079 REGRESSION** — Full Journal native `Save As` ownership перенесён из service worker в `journal.html`.
- **P1-080 REGRESSION** — OperationLog JSON native `Save As` ownership перенесён из service worker в `options.html`.
- **P1-081 REGRESSION** — OperationLog v2 normal append/mutate/list/get/clear IDB transactions bounded/abortable.
- **P1-082 REGRESSION** — durable recovery stores pendingAppends/pendingRemoteSaves/pendingDownloads CRUD получили IDB deadlines.
- **P1-083 REGRESSION** — ordinary Journal CRUD/read/scan/stats IDB transactions bounded/abortable.
- **P1-084 REGRESSION** — PDF retry-cache CRUD IDB transactions bounded/abortable.
- **P1-085 REGRESSION** — `journal.html` direct readonly IndexedDB path имеет timeout/abort и штатный service-worker fallback.
- **P1-086 REGRESSION** — bounded readonly IDB helpers settle только на `tx.oncomplete`, не на раннем `request.onsuccess`.
- **P1-087 REGRESSION** — local download recovery fallback матчится только с `DownloadItem.byExtensionId` этого extension, а не по имени/размеру чужой загрузки.
- **P1-088 REGRESSION** — `chrome.downloads.search()` в local save/reconciliation имеет bounded deadline; checkpoint остаётся для retry.

## P1-089…P1-092

История явно указывала, что коды **P1-089…P1-093 уже существовали**. Полные формулировки P1-089/P1-091/P1-092 не сохранились в доступных артефактах. **Не переиспользовать.**

- **P1-090 OPEN (known)** — Yandex identity/locator design. Не менять shared delete flow без нового воспроизведения/operation log согласно требованию пользователя.
- P1-089 — RESERVED, exact wording unavailable in mounted artifacts.
- P1-091 — RESERVED, exact wording unavailable in mounted artifacts.
- P1-092 — RESERVED, exact wording unavailable in mounted artifacts.

## P1-093…P1-102

- **P1-093 REGRESSION** — PDF `Page.printToPDF` → `ReturnAsStream`; bounded `IO.read`, byte/time budget, mandatory `IO.close`; без full Base64 PDF heap copy.
- **P1-094 REGRESSION** — `webclipJournalContext:*` получает bounded URL, TTL 24h и hard cap 512 session contexts.
- **P1-095 REGRESSION** — global PDF generation budget: одновременно одна PDF generation, не только per-tab debugger guard.
- **P1-096 REGRESSION** — scoped MV3 keep-alive heartbeat вокруг действительно долгих alarm-owned jobs, cleanup в `finally`.
- **P1-097 REGRESSION** — scoped keep-alive для manual Yandex backup до offscreen/network stage.
- **P1-098 REGRESSION** — targeted keep-alive allowlist для потенциально долгих runtime jobs (journal scans/export/import/clear/backup/cleanup).
- **P1-099 REGRESSION** — ad scan content script: bounded TreeWalker, без `[root,...querySelectorAll('*')]`; лимиты ~50k nodes/1000 candidates.
- **P1-100 REGRESSION** — main-content auto detection: bounded candidate discovery/subtree metrics, без повторной full `innerText/querySelectorAll` materialization.
- **P1-101 REGRESSION** — snapshot locator fallback: bounded TreeWalker/text extraction, без full `querySelectorAll(tag)` materialization.
- **P1-102 REGRESSION** — frame document traversal iterative/bounded: caps documents/frame elements/DOM nodes; listeners не растут без лимита.

## P1-103…P1-113

- **P1-103 REGRESSION** — storage/quota preflight `navigator.storage.estimate()` bounded; mandatory large-write preflight не silently fail-open при недоступной оценке.
- **P1-104 REGRESSION** — security `setAccessLevel(TRUSTED_CONTEXTS)` calls имеют deadline, чтобы security initialization не завис навсегда.
- **P1-105 REGRESSION** — offscreen close reconciliation не трактует ошибку `getContexts()` как доказательство закрытия; latch восстанавливается fail-closed.
- **P1-106 REGRESSION** — keep-alive heartbeat Chrome API pulse bounded; один hung pulse не отключает все будущие pulses.
- **P1-107 REGRESSION** — content selection live DOM references ограничены тем же Include/Exclude boundary, что snapshot.
- **P1-108 REGRESSION** — PDF preprocessing links/images/disclosures использует общий bounded TreeWalker, без full subtree `querySelectorAll` materialization.
- **P1-109 REGRESSION** — locator-generation structural path не materialize'ит всех siblings/ID matches; bounded sibling walk.
- **P1-110 REGRESSION** — update lifecycle version marker фиксируется только после bounded successful extension-page refresh; unknown result повторяется на следующем wake.
- **P1-111 REGRESSION** — Yandex OAuth credential storage reads/writes/removes имеют deadlines при сохранении session-only/fail-closed модели.
- **P1-112 REGRESSION** — full all-tabs action refresh не выполняется на каждом MV3 wake; только startup/install + bounded concurrency, events остаются точечными.
- **P1-113 REGRESSION** — two-phase native Save As получил session handoff checkpoint + downloads reconciliation + stale OperationLog closure; native prompt остаётся в extension page.

## P1-114…P1-123

- **P1-114 REGRESSION** — rejected offscreen idle-close request re-arms cleanup timer.
- **P1-115 REGRESSION** — offscreen transfer heartbeat имеет in-flight guard/deadline, не накапливает pending runtime promises.
- **P1-116 REGRESSION** — whole-object `yandexConfig` read-modify-write mutations сериализованы; fresh read внутри queue + late-settlement barrier предотвращают lost update.
- **P1-117 REGRESSION** — durable backup checkpoint/state storage mutations bounded + late-settlement barrier; stale late set не resurrect'ит checkpoint.
- **P1-118 REGRESSION** — `alarms.create/clear` serialized/bounded; late clear старой операции не удаляет новый alarm.
- **P1-119 REGRESSION** — maintenance scheduler `alarms.get/create` и prerequisite settings read bounded, чтобы recovery alarm всегда мог self-heal.
- **P1-120 REGRESSION** — crash-consistency marker `webclipJournalStatsDirty` storage mutations serialized with late-settlement barrier.
- **P1-121 REGRESSION** — retention-setting storage mutation serialized/bounded against late stale write.
- **P1-122 REGRESSION** — legacy pending-append migration storage get/remove bounded.
- **P1-123 REGRESSION** — journal source-context session get/remove/set bounded; opening Journal не зависает до tab creation.

## P1-124…P1-131

- **P1-124 REGRESSION** — `tabs.create()` bounded + duplicate-safe late-result reconciliation.
- **P1-125 REGRESSION** — `scripting.executeScript()` bounded; late injection безопасна через singleton guard.
- **P1-126 REGRESSION** — оставшиеся service-worker `tabs.get()` bounded.
- **P1-127 REGRESSION** — Journal extension-page Chrome API health/context/restore calls bounded.
- **P1-128 REGRESSION** — hanging offscreen idle-close `runtime.sendMessage` получает deadline и re-arm cleanup.
- **P1-129 REGRESSION** — prepared Save-As session checkpoint mutations сериализованы с late-settlement barrier.
- **P1-130 REGRESSION** — Chrome Action setIcon/setBadge/setTitle: per-tab deadline + late-settlement fence + global pending cap.
- **P1-131 REGRESSION** — timed-out/unknown debugger attach/detach consumes global PDF pending budget, предотвращая накопление hangs по разным tabId.

## P2-009…P2-010

- **P2-009 REGRESSION** — Yandex OAuth help исправлен: access token session-only, не `storage.local`; refresh token/Client Secret не сохраняются.
- **P2-010 REGRESSION** — `journalHealthTimer` больше не implicit global; явный scoped lifecycle variable.
