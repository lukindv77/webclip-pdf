# ARTIFACT INDEX

- `README_FIRST.md` — обязательная стартовая точка.
- `CURRENT_STATE.md` — текущая physical/release state.
- `AUDIT_STATUS.md` — gate/evidence.
- `PENDING_WORK.md` — незакрытый backlog.
- `STATIC_CHECKS.md` — последний локальный/browser gate.
- `REGISTRY_CONFLICTS_AND_GAPS.md` — P-code reservations/conflicts.
- `AUDIT_HISTORY_RESERVED_CODES.md` — сохранённые history specifications + current addendum.
- `MERGE_AND_RECOVERY_ORDER.md` — правила восстановления/продолжения.
- `CHAT_PROGRESS_FEATURE_BATCH.md` — feature batch теперь superseded physical closures.
- `GITHUB_SYNC.md` — canonical private remote и sync policy.
- `PROMPT_FOR_NEW_CHAT.md` — готовый prompt.
- `current_recovery_snapshot/current_wip/` — точный physical WIP.
- `project_recovery/*.zip` намеренно не вложен как дублирующий generated artifact; rebuild tool и все source/docs присутствуют.
