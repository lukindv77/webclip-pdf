# AUDIT STATUS

## Gate

Audit gate остаётся **OPEN**. Текущая ветка regression-tested локально, но **не является release QA**.

## Последние закрытия

- `P1-090 = REGRESSION`: Yandex identity `accountUid + rootPath + resourceId + publicUrl + remotePath`, account/root mismatch fail-before-lookup, resourceId сильнее path/publicUrl.
- `P1-074 = REGRESSION`: hung IDB import staging phases bounded/abortable; старый Journal не заменяется после staging timeout.
- `P1-079 = REGRESSION`: Full Journal native `Save As` принадлежит `journal.html`, без caller timeout/retry вокруг системного диалога.
- `P1-080 = REGRESSION`: OperationLog native `Save As` принадлежит `options.html`, без caller timeout/retry.

## Последний regression gate

- 68/68 JS syntax PASS;
- 55/55 deterministic tests PASS;
- Chromium browser regressions P1-001/003/004/008/009/025/026/027/028/079-080 PASS;
- P1-007 managed integration PASS; PDF 37,501 bytes selected-only; Journal PASS; mocked Yandex PASS;
- manifest MV3 / 0.9.8 PASS.

## Release QA still required

- real unpacked Chrome/Chrome for Testing extension load;
- real optional-host permission prompt + real HTTP(S) cross-origin iframe;
- real Yandex OAuth/account/root and upload/download/Trash flows;
- real native Save As user interaction for Full Journal and OperationLog;
- release scenarios from `project_docs/TEST_PLAN.md`.
