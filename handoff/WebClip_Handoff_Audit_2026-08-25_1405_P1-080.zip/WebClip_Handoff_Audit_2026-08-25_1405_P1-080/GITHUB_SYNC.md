# GitHub state / manual sync checkpoint

Canonical private remote: **`lukindv77/webclip-pdf`**, branch `main`.

Before this handoff was built, the failed bootstrap transport was removed from the active branch by force-resetting `main` to the last known-clean commit:

`e4ae66c6b677c6e49841caf3c9aa5ce7e970fa7a` — `chore: add WebClip repository ignore rules`

At that checkpoint the active `main` contains only the original repository README and the protective `.gitignore`; `.bootstrap/*` and temporary sync workflows are not part of active `main`.

The user will manually upload the starter package through PowerShell. Therefore, on a new chat:

1. Treat `current_recovery_snapshot/current_wip/` in this handoff as the source of truth until GitHub is verified.
2. Inspect `lukindv77/webclip-pdf:main` before relying on it.
3. If `manifest.json` exists at repository root and is MV3 / `0.9.8`, compare key current files/status docs with this handoff, then GitHub may be used as canonical remote.
4. Do not resurrect `.bootstrap` or `sync-current-webclip.yml`; they were failed transport scaffolding, not product architecture.
5. Keep secrets, `.env`, browser profiles, caches and ad-hoc recovery ZIPs outside git.
6. The canonical handoff ZIP is intended to live under `handoff/` with its `.sha256` once manual upload completes.
