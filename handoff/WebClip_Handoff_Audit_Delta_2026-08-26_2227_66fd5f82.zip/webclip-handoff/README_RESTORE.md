# Restore / new-chat use

Use GitHub `main` first. This delta ZIP is paired with the full base handoff ZIP listed in `ARCHIVE_MANIFEST`. The current-state and prompt files contain the exact audit continuation point and product invariants.
