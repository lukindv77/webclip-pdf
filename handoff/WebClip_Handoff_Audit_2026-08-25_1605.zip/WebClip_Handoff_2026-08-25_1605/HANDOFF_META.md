# Handoff metadata

Repository: lukindv77/webclip-pdf
Branch: main
Handoff source commit: d921dfffa9dabcb99a58cc4f0c8cfc423b63e3ee
Manifest: MV3 / 0.9.8
Gate at packaging: 68/68 JS syntax PASS; 55/55 deterministic tests PASS
Published build release: v0.9.8-build-20260825-1442
Published build SHA-256: cd40a7d248936015e629aaef134004ef14ee422230e54ffac6e912ceb29521a4

Start with repository/PROMPT_FOR_NEW_CHAT.md and repository/handoff/CURRENT_STATE_2026-08-25_1605.md.
The archive excludes older handoff ZIP files and the large builds/*.zip copy; build metadata/checksums and the GitHub Release remain in the repository.
