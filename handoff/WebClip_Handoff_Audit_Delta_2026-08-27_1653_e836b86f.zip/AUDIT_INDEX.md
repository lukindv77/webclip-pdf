# Audit/handoff index for the next chat

Read:
1. GITHUB_REPOSITORY_STATE.md
2. handoff/LATEST.md
3. handoff/CURRENT_STATE_2026-08-27_1653.md
4. PROMPT_FOR_NEW_CHAT.md
5. project_docs/PRIORITIES_P0_P1_P2.md
6. DEEP_AUDIT_2026-08-25.md
7. all project_docs/AUDIT_DELTA_*.md

Recent delta subjects include Yandex OAuth capability/validity; mutation/recovery; backup/import; auth/config races; Journal concurrency; document identity; local download recovery; offscreen/IDB; restore envelope; URL privacy/flattened print; hostile control plane; durability class; imported provenance; frame-agent identity; publication policy; Chrome read admission; MV3 lifecycle; PDF cache ownership; OperationLog clear generation P1-197; operation identity P1-198; print generation P1-199; selection/control generation P1-200; local recovery fairness; remote frame fan-out; legacy Yandex account binding; active import staging lifetime.

Never assume a number is free from canonical tables alone.
