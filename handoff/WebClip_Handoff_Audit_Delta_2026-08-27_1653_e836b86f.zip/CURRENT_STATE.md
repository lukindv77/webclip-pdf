# CURRENT STATE — WebClip PDF handoff — 2026-08-27 16:53 +07

## Repository authority
- Repository: `lukindv77/webclip-pdf`
- Branch: `main`
- Pre-handoff source HEAD: `e836b86f322713bf960626a6733bfaeafaf99411`
- Pre-handoff tree: `61e92fca5d8f0d6b6ff35e0e26f5bab498de7d89`
- Previous handoff source: `66fd5f828639a9d29f85013fedd4185cd4168e09`
- GitHub `main` is the only source of truth.

## Product
- MV3 / version `0.9.8` / Chrome >=118
- No 0.9.9 bump or release without explicit post-QA request.

## Last proven tests
- 88/88 JS syntax PASS
- 74/74 deterministic PASS
- Not rerun after the later docs-only audit stream.

## Recovery
Full source base:
`handoff/WebClip_Handoff_Audit_2026-08-26_1047_a57042fe.zip`
SHA-256 `b9e1fa364bacc8fa21da29d0c721307cc7aa29051e2178f3123da65d3f46ff14`

Exact current source is Git `main`; the new ZIP is context/audit delta.

## Work discipline
Fresh-fetch main before write; newer main wins; source proof + semantic duplicate-check; search canonical + all AUDIT_DELTA files; stable numbers never reused; audit in large blocks; docs-only checkpoints for confirmed evidence; canonical sync only when both large audit docs are updated together; no unproven test claims.

## Core invariants
Session-only access token; PKCE S256/no client_secret; hostile DOM; Incognito fail-closed; timeout != cancellation; no blind retry unknown non-idempotent side effects; page-owned native Save As/no artificial timeout; bounded offscreen/Blob/PDF/IDB/runtime; durable checkpoint before irreversible effect; exact document/operation/account/root/object/content provenance; full PSL; explicit optional host permission for cross-origin frames; debugger/Page.printToPDF remains current PDF mechanism.

## Evidence-reserved highlights
- P0-079 operation-owned PDF bytes/cache
- P1-195 Yandex capability/scope truthfulness
- P1-196 Yandex validity/lifetime truthfulness
- P1-197 OperationLog history generation (already in audit delta)
- P1-198 trusted worker-owned operation identity
- P1-199 cross-origin print prepare/restore generation
- P1-200 cross-origin selection/control generation

## Reopened/refined existing clusters
P0-022, P0-023, P0-039, P0-048, P0-050, P0-066, P0-068, P0-069, P0-071, P0-073, P0-074, P0-075, P0-076, P0-077, P0-078;
P1-035, P1-043, P1-052, P1-064, P1-086, P1-090, P1-138, P1-158, P1-164, P1-167, P1-171, P1-173, P1-175, P1-177, P1-178, P1-182, P1-183, P1-184, P1-188, P1-189, P1-190, P1-192, P1-193, P1-194.

## Recent proof details
- P1-200: fire-and-forget start/stop/set-mode/clear/restore can reorder; child Escape sends idle state but top ignores phase.
- P1-199: stale restore can undo new print prep; repeated prepare can orphan prior style due one mutable pointer.
- P0-074: testYandexConnection response A can cache account A into active token B; getCurrentYandexAccountUid then trusts stale cache.
- P1-035: 2h maintenance TTL can delete staging while a live confirmation dialog still presents Proceed.
- P1-064: oldest 12 in-progress local downloads can starve newer terminal recovery checkpoints.
- P1-167: up to 64 remote frames with sequential permission/message waits can consume hundreds of seconds before PDF print deadline.
- P0-073: missing expected accountUid on legacy/local entry must not be wildcard destructive authority.
- P0-079: tab-owned mutable PDF cache causes cross-operation TOCTOU and tab-close cleanup risks.

## Positive controls already revalidated
Offscreen RPC sender ACL; offscreen idle-close latch; Yandex list pagination explicit fail at caps; backup ms timestamp + lease; Journal export DB revision before/after; exact stagingKey replace; no reviewed imported-string extension-page innerHTML XSS; hidden final cross-origin child URL not directly serialized; Yandex publicUrl privileged open host allowlist; crypto 9-digit code; managed-root containment after remote locate.

## Canonical caveat
Latest evidence-reserved items may not be present in both canonical audit files. Search all project_docs before allocating numbers. Do not treat P1-201 or any later number as free without a fresh whole-repo search.

## Release blockers
Close P0 identity/privacy/data-loss blockers and key P1 auth/generation/settlement/recovery blockers; canonical sync; rerun full tests; real unpacked Chrome QA; real Yandex E2E; MV3 restart; Incognito; optional iframe permission/revoke; then explicit release request.

## Next continuation
If no newer GitHub work changes priorities, continue large-block audit around Yandex destructive/recovery object/content binding and cross-context actual-settlement ordering.
